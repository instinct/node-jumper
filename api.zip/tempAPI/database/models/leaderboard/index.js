module.exports = function(sequelize, dataTypes){
	return sequelize.define('leaderboards', {
		id: {
			type: dataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true
		},
		user: dataTypes.STRING,
		score: dataTypes.INTEGER,
		game: dataTypes.STRING,
		date: dataTypes.DATE,
		user_id: dataTypes.INTEGER,
		data: dataTypes.TEXT,
	}, {
		tableName: 'wp_gf_leaderboards',
		timestamps: true,
		createdAt: 'date',
		updatedAt: false,
		deletedAt: false		
	});
}