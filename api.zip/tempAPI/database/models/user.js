module.exports = function(sequelize, dataTypes){
	return sequelize.define('user', {
		ID: {
			type: dataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true
		},
		user_login: dataTypes.STRING,
		user_pass: dataTypes.STRING,
		user_nicename: dataTypes.STRING,
		user_email: dataTypes.STRING,
		user_url: dataTypes.STRING,
		user_registered: dataTypes.DATE,
		user_activation_key: dataTypes.STRING,
		user_status: dataTypes.INTEGER,
		display_name: dataTypes.STRING,
		version: dataTypes.INTEGER
	}, {
		tableName: 'wp_users',
		updatedAt: false,
		createdAt: false,
	});
}