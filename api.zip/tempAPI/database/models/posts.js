module.exports = function(sequelize, dataTypes){
	return sequelize.define('post', {
		ID: {
			type: dataTypes.BIGINT,
			primaryKey: true,
			autoIncrement: true
		},
		post_author: dataTypes.BIGINT,
		post_date: dataTypes.DATE,
		post_date_gmt: dataTypes.DATE,
		post_content: dataTypes.TEXT,
		post_title: dataTypes.TEXT,
		post_excerpt: dataTypes.TEXT,
		post_status: dataTypes.STRING,
		comment_status: dataTypes.STRING,
		ping_status: dataTypes.STRING,
		post_password: dataTypes.STRING,
		post_name: dataTypes.STRING,
		to_ping: dataTypes.TEXT,
		pinged: dataTypes.TEXT,
		post_modified: dataTypes.DATE,
		post_modified_gmt: dataTypes.DATE,
		post_content_filtered: dataTypes.TEXT,
		post_parent: dataTypes.BIGINT,
		guid: dataTypes.INTEGER,
		menu_order: dataTypes.INTEGER,
		post_type: dataTypes.STRING,
		post_mime_type: dataTypes.STRING,
		comment_count: dataTypes.BIGINT
	}, {
		tableName: 'wp_posts',
		timestamp: false
	});
}