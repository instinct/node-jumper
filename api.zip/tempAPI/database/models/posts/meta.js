module.exports = function(sequelize, dataTypes){
	return sequelize.define('post_meta', {
		meta_id: {
			type: dataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true
		},
		post_id: dataTypes.INTEGER,
		meta_key: dataTypes.STRING,
		meta_value: dataTypes.TEXT
	}, {
		tableName: 'wp_postmeta',
		timestamps: false		
	});
}