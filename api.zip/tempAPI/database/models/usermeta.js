module.exports = function(sequelize, dataTypes){
	return sequelize.define('user_meta', {
		umeta_id: {
			type: dataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true
		},
		user_id: dataTypes.INTEGER,
		meta_key: dataTypes.STRING,
		meta_value: dataTypes.TEXT
	}, {
		tableName: 'wp_usermeta',
		timestamps: false		
	});
}