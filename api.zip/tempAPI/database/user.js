var tools = require('../tools/');
var unserialize = require('php-unserialize');


//import modules...
var user, user_meta;

var users = function(db, sequelize){
    this.db = db;
    this.sequelize = sequelize;
    user = sequelize.import(__dirname + '/models/user');
    user_meta = sequelize.import(__dirname + '/models/usermeta');
    return this;
};

users.prototype = {
    getUsersFriends: function (userID, callback) {
        userID = wordpress.filter(userID);
        var query = '(initiator_user_id = ? or friend_user_id = ?) AND is_confirmed = 1';
        wordpress.get('wp_bp_friends', null, query, [userID, userID], false, callback);
    },
    getUserByID: function (id, callback) {
        var self = this;
        user.find({
            where: {
              ID: id
            }
        }).then(function( user ){
            user_meta.findAll({
                where: {
                  user_id: id
                },
                attributes: ['meta_key', 'meta_value']
            }).success(function( usermeta ){
                callback(false, sortUser(user, usermeta));
            });
        });
    },
    updateAccount: function( id, body ){
        if (id){
           if (body.picture){
              user_meta.create({
                meta_key: 'fb_image',
                meta_value: body.picture,
                user_id: id
              }).success(function(){
                  console.log( 'working' );
              });
           }
        }
        return false;
    },
    getUserByEmail: function(email, cb){
        console.log( email );
        new this.db.builder().select('*').from(this.db.prefix('users')).where('user_email', email).execute(function(err, res){
           if (!this.isError()){
               cb(false, res);
           } else {
               cb(err, false);
           }
        });
    },    
    checkIfFbUserExists: function (id, callback) {
        var fb_id = wordpress.filter(parseInt(id));
        wordpress.get('wp_usermeta', null, 'meta_key = "fbuid" AND meta_value = ?', [fb_id], false, callback);
    },
    getUsersPerms: function (id, callback, sort) {
        var userID = wp.filter(id);
        wp.get('wp_usermeta', null, 'meta_value', 'meta_key = "wp_capabilities" AND user_id = ?', [userID], callback, sort);
    },
    getUserByUsername: function(name, callback){
        new this.db.builder().select('*').from(this.db.prefix('users')).where('user_login', name).execute(function(err, res){
            if (!this.isError()){
                callback(false, res);
            } else {
                callback(err, false);
            }
        });
    },
    getUsersLevels: function(id, cb){
        //now we are chaning it to support, older games :)
        var self = this;
        var counter = 0;

        new this.db.builder().select('ID, post_title, post_date').from('wp_posts').where({'post_type': 'game', 'post_author': id}).exec(function(err, res){
              if (!err && res && res[0]){
                  var games = [];
                  tools.each(res, function(){
                      counter++;
                      var id = this.ID;
                      setTimeout((function(post){
                          new self.db.builder().select('meta_key, meta_value').from(self.db.prefix('postmeta')).where('post_id', id).exec(function(err, result){
                            counter--;
                             if (!err && result){
                                 var level = {};
                                 tools.each(result, function(){
                                     if (this.meta_key === 'version'){
                                         level.version = parseFloat(this.meta_value);
                                     } else if (this.meta_key === 'image'){
                                         level.image = this.meta_value;
                                     }
                                 });
                                 level.id = post.ID;
                                 level.title = post.post_title;
                                 level.date = post.post_date;
                                 games.push(level);
                             } else {
                                 console.log(err);
                             }

                             if (counter === 0){
                                 cb(false, games);
                             }
                          });
                      })(this), 1);
                  });
              } else {
                cb(false, []);
              }
        });


        //var query = "SELECT wp.ID, wp.post_date, wp.post_title, wp.post_status, pm.meta_value FROM wp_posts AS wp INNER JOIN wp_postmeta as pm ON wp.ID = pm.post_id WHERE wp.post_author = ? AND wp.post_type = 'game' AND pm.meta_key = 'image'";
        //new this.db.builder().query(query, [id], cb);
    },

    getPack: function(id, cb){
       new this.db.builder().select('meta_value').from(this.db.prefix('usermeta')).where('user_id', id).and().where('meta_key', 'user_pack').exec(function(err, res){
           if (!this.isError()){
               cb(false, res);
           } else {
               cb(err, false);
           }
       });
    },

    //inserts...
    insertUser: function(user_login, user_pass, user_nicename, user_email, user_url, user_registered, user_activation_key, user_status, display_name, version, ref, cb){
        var self = this;
        new this.db.builder().insert(this.db.prefix('users')).set({
            user_login: user_login,
            user_pass: user_pass,
            user_nicename: user_nicename,
            user_email: user_email,
            user_url: user_url,
            user_registered: user_registered,
            user_activation_key: user_activation_key,
            user_status: user_status,
            display_name: display_name,
            version: version
        }).execute(function(err){
            if (!this.isError()){
                var id = this.getID();
                cb(false, id);
                //inserts all the meta
                new self.db.builder().insert(self.db.prefix('usermeta')).set({
                    user_id: id,
                    meta_key: 'first_name',
                    meta_value: ''
                }).exec(null);
                new self.db.builder().insert(self.db.prefix('usermeta')).set({
                    user_id: id,
                    meta_key: 'user_pack',
                    meta_value: '[]'
                }).exec(null);
                new self.db.builder().insert(self.db.prefix('usermeta')).set({
                    user_id: id,
                    meta_key: 'last_name',
                    meta_value: ''
                }).exec(null);
                new self.db.builder().insert(self.db.prefix('usermeta')).set({
                    user_id: id,
                    meta_key: 'nickname',
                    meta_value: user_nicename
                }).exec(null);
                new self.db.builder().insert(self.db.prefix('usermeta')).set({
                    user_id: id,
                    meta_key: 'description',
                    meta_value: ''
                }).exec(null);
                new self.db.builder().insert(self.db.prefix('usermeta')).set({
                    user_id: id,
                    meta_key: 'rich_editing',
                    meta_value: 'true'
                }).exec(null);
                new self.db.builder().insert(self.db.prefix('usermeta')).set({
                    user_id: id,
                    meta_key: 'comment_shortcuts',
                    meta_value: 'false'
                }).exec(null);
                new self.db.builder().insert(self.db.prefix('usermeta')).set({
                    user_id: id,
                    meta_key: 'admin_color',
                    meta_value: 'fresh'
                }).exec(null);
                new self.db.builder().insert(self.db.prefix('usermeta')).set({
                    user_id: id,
                    meta_key: 'use_ssl',
                    meta_value: '0'
                }).exec(null);
                new self.db.builder().insert(self.db.prefix('usermeta')).set({
                    user_id: id,
                    meta_key: 'show_admin_bar_front',
                    meta_value: 'true'
                }).exec(null);
                new self.db.builder().insert(self.db.prefix('usermeta')).set({
                    user_id: id,
                    meta_key: 'wp_capabilites',
                    meta_value: 'a:1:{s:10:"subscriber";b:1;}'
                }).exec(null);
                new self.db.builder().insert(self.db.prefix('usermeta')).set({
                    user_id: id,
                    meta_key: 'wp_user_level',
                    meta_value: '0'
                }).exec(null);
                new self.db.builder().insert(self.db.prefix('usermeta')).set({
                    user_id: id,
                    meta_key: 'bp_xprofile_visibility_levels',
                    meta_value: '0'
                }).exec(null);
                new self.db.builder().insert(self.db.prefix('usermeta')).set({
                    user_id: id,
                    meta_key: 'activation_key',
                    meta_value: '0'
                }).exec(null);
                new self.db.builder().insert(self.db.prefix('usermeta')).set({
                    user_id: id,
                    meta_key: 'ref',
                    meta_value: ref
                }).exec(null);

            } else {
                cb(err, true);
            }
        });
    },
    insertFBUser: function(options, cb){
        var self = this;
        new this.db.builder().insert(this.db.prefix('users')).set(options.user).exec(function(err, res){
           if (!err && res){
               console.log( res );
               var id = res.insertId;
               tools.each(options.usermeta, function(key, value){
                   new self.db.builder().insert(self.db.prefix('usermeta')).set({meta_key: key, meta_value: value, user_id: id}).exec(false);
               });
               cb(false, id);
           }
            console.log(err, res);
        });
    },
    getPacksByUser: function(id, cb){
        var self = this;
        var packs = [];
        new this.db.builder().select('ID').from(this.db.prefix('posts')).where('post_author', id).and().where('post_type', 'wpsc-product').exec(function(err, packs){
            new self.db.builder().select('meta_value').from(self.db.prefix('usermeta')).where({user_id: id, meta_key: 'purchased_packs'}).exec(function(err, value){
               if (!err && value && value[0] && value[0].meta_value){
                   var puchasedpacks = value[0].meta_value.replace(/[ "\[\]]/gi, '').split(',');
                   for (var i = 0; i < puchasedpacks.length; i++){
                       if (parseInt(puchasedpacks[i])){
                            packs.push({ID: puchasedpacks[i]});
                       }
                   }
               }
               cb(false, packs);
            });
        });
    },
    getAll: function(cb){
       new this.db.builder().select('ID, user_nicename, user_login').from(this.db.prefix('users')).exec(function(err, value){
            if (!err && value){
                cb(false, value);
            } else {
                cb(err, false);
            }
       });
    },
    getUserByFBID: function(id, cb){
        new this.db.builder().select('user_id').from(this.db.prefix('usermeta')).where({meta_key: 'fb_uid', meta_value: id}).limit(1).exec(function(err, res){
            if (!err && res && res[0]){
                cb(false, res[0]);
            } else {
                cb(false, {});
            }
        });
    },
    setUserMeta: function(userID, key, value){
        var self = this;
        if (userID){
            new this.db.builder().update(this.db.prefix('usermeta')).set('meta_value', value).where({'meta_key': key, user_id: userID}).exec(function(err, res){
                if (!err && res){
                    if (res.affectedRows === 0){
                        //hmmm no postmeta with this id.... should we do something about this??? probably...
                        self.insertMeta(userID, key, value);
                    }
                }
            });
        }
    },
    insertMeta: function(userID, meta_key, meta_value, cb){
        new this.db.builder().insert(this.db.prefix('usermeta')).set({
            'user_id': userID,
            'meta_key': meta_key,
            'meta_value': meta_value
        }).exec(function(err, id){
            if (this.isError()){
                if (cb){
                    cb(err, false);
                }
            } else {
                if (cb){
                    cb(false, id);
                }
            }
        })
    },
    getUserMeta: function(userID, key, callback){
        new this.db.builder().select('meta_value').from(this.db.prefix('usermeta')).where({'meta_key': key, user_id: userID}).exec(function(err, res){
            if (!err && res){
                callback(res[0]);
            }
        });
    },
    attachApiKey: function( userID, apiKey, cb ){
      var self = this;
      new this.db.builder().select('*').from(this.db.prefix('usermeta')).where('meta_key', 'api-key').exec(function(err, res) {
        if (!err && res && res.length == 0){
          new self.db.builder().insert(self.db.prefix('usermeta')).set({
              user_id: userID,
              meta_key: 'api-key',
              meta_value: apiKey
          }).exec(cb); 
        } else {
          cb({msg: 'woop\'s, you already have an api-key, here it is', apiKey: res[0].meta_value}, false);
        }
      });
    }
};


function sortUser(user, usermeta){
    var user_data = user.dataValues;
    var length = usermeta.length;
    for (var i = 0; i < length; i++){
        var dataValue = usermeta[i].dataValues;
        if ( dataValue && dataValue.meta_value && dataValue.meta_value.indexOf('{') != -1 && dataValue.meta_key == 'wp_capabilites' ){
            dataValue.meta_value = unserialize.unserialize( dataValue.meta_value );
        }
        user_data[ dataValue.meta_key ] = dataValue.meta_value;
    }
    return user_data;
};



module.exports = users;


//SELECT wp.ID, wp.post_date, wp.post_title, wp.post_status, pm.meta_value FROM wp_posts AS wp INNER JOIN wp_postmeta as pm ON wp.ID = pm.post_id WHERE wp.post_author = '4205' AND wp.post_type = 'game'