/*
* This is the core code for the database
* This is just some simple functions that do the main part of everything for me :)
*/

var mysql = require('mysql'),
    os = require('os'),
    tools = require('../tools/'),
    fs = require('fs');

var config = require('../config-loader')(__dirname + '/../config/', {});

var Sequelize = require("sequelize");
var sequelize = new Sequelize(config.adapters.mysql.database, config.adapters.mysql.user, config.adapters.mysql.password, {
  logging: config.adapters.logging
});

var db = function(){
  //we will just get the connection....
    return this;
};


db.prototype.isError = function(){
    return self.err? true : false;
};

db.prototype.filter = function(value){
    if (typeof value == 'string'){
        return value.replace(/drop[<>'"]/gi, '');
    } else {
        return '';
    }
};

db.prototype.prefix = function(value){
   return this.filter('wp_' + value);
};



/*
* Starts the builder...
* this is a simple function for building safe queries...
*/

db.prototype.builder = function(){
    return this;
};

var builder = db.prototype.builder;

builder.prototype.query = function(query, values, cb){
    var self = this;
    try {
        var startTime = new Date();
        sql.getConnection(function(err, connection){
            if (!err){
                connection.query(query, values, function(err, res){
                    if (typeof cb == 'function'){
                        cb(err, res);
                    }
                    var endTime = new Date() - startTime;
                    if (global.app && global.app.debug) {
                        fs.writeFileSync(global.app.directory + '/logs/mysql.txt', 'query: ' + query + ': Time -:- ' + endTime + 'ms \n', {flag: 'a+'});
                    }
                    connection.release();
                });
            }
        });

    } catch (e){
        if (self.cb){
            self.cb.apply(self, e, []);
        } else {
            console.log(e);
        }
    }
};

builder.prototype.isError = function(){
   return this.error != null;
};

builder.prototype.execute = builder.prototype.exec = function(cb){
    var self = this;
    self.cb = cb;
    if (this.queryString){
        self.query(this.queryString, this.values, function(err, value){
            self.result = value || [];
            self.error = err || null;
            var cb = self.cb;
            delete self.cb;
            if (typeof cb == 'function'){
                cb.call(self, err, value || []);
            }
        });
    }
};


/**
 * From table
 * @param from
 * @returns {db.prototype.builder}
 */
builder.prototype.from = function(from){
    this.queryString += ' FROM ' + filter(from);
    return this;
};

/**
 * And query
 * @returns {db.prototype.builder}
 */
builder.prototype.and = function(){
    this.queryString += ' AND ';
    return this;
};


/**
 * Where Query
 * @returns {db.prototype.builder}
 */

builder.prototype.where = function(){
    //core value...
    var self = this;
    var length = arguments.length || 0;
    var value = arguments[1] || '';
    var key = arguments[0] || '';
    var baseWhere = '';
    if (!this.addedWhere){
        baseWhere = " WHERE "
    } else {
        baseWhere = '';
    }
    this.addedWhere = true;

    if (!self.values){
        self.values = [];
    }

    if (length == 1 && typeof key == 'object'){
        //this will just be something like where ({fred: 1});
        var whereString = baseWhere;
        var whereArray = [];
        tools.each(key, function(i, value){
            if (whereArray.length >= 1){
                whereArray.push(' AND ' + filter(i) + ' = ?');
            } else {
                whereArray.push(' ' + filter(i) + ' = ?');
            }
            self.values.push(value);
        });
        this.queryString += whereString + whereArray.join('');
    } else {
        //this will just be something like ('fred', 1);
        self.queryString += baseWhere;

        self.queryString += key + ' = ?';
        self.values.push(value);
    }

    return self;
};

/**
 * Like Query
 * @returns {db.prototype.builder}
 */
builder.prototype.like = function(){
    //core value...
    var self = this;
    var length = arguments.length || 0;
    var value = arguments[1] || '';
    var key = arguments[0] || '';
    var baseWhere = '';
    if (!this.addedWhere){
        baseWhere = " WHERE "
    } else {
        baseWhere = '';
    }
    this.addedWhere = true;

    if (!self.values){
        self.values = [];
    }

    if (length == 1 && typeof key == 'object'){
        //this will just be something like where ({fred: 1});
        var whereString = baseWhere;
        var whereArray = [];
        tools.each(key, function(i, value){
            if (whereArray.length >= 1){
                whereArray.push(' AND ' + filter(i) + " LIKE ?");
            } else {
                whereArray.push(' ' + filter(i) + " LIKE ?'");
            }
            self.values.push(value);
        });
        this.queryString += whereString + whereArray.join('');
    } else {
        //this will just be something like ('fred', 1);
        self.queryString += baseWhere;

        self.queryString += key + " LIKE ?";
        self.values.push(value);
    }
    return self;
};

/**
 * The main select query
 * @param value
 * @returns {db.prototype.builder}
 */
builder.prototype.select = function(value){
    var length = arguments.length;
    if (length > 1){
        var selects = [];
        tools.each(arguments, function(i, value){
            selects.push(value);
        });

        this.selectQuery = selects.join(',');
        this.selectQuery = filter(this.selectQuery);
        this.queryString = "SELECT " + this.selectQuery;
    } else {
        this.queryString = "SELECT " + filter(value);
    }
    return this;
};

/**
 * Simple limit function
 * @param value
 * @returns {db.prototype.builder}
 */
builder.prototype.limit = function(value){
    this.queryString += " LIMIT " + filter(value);
    return this;
};


builder.prototype.order = function(row, type){
    this.queryString += ' ORDER BY ' + filter(row) + ' ' + filter(type);
    return this;
};

//TODO::
// ADD a order prototype
// ADD a groupby prototype
// ADD a date function like "MYSQL_DATE()"


/*
* JOINS
*/


/**
 * Left join main...
 * @param table
 * @param type
 * @returns {db.prototype.builder}
 */

builder.prototype.join = function(table, type){
    switch (type.toUpperCase()){
        case 'LEFT':
            this.queryString += ' LEFT JOIN ' + filter(table) + ' ';
            break;
    }
  return this;
};

/**
 * The on operator
 * @param value1
 * @param operator
 * @param value2
 * @returns {db.prototype.builder}
 */

builder.prototype.on = function(value1, operator, value2){
    var self = this;
    if (operator == '='){
       if (operator.indexOf('JOIN') != -1){
           return self; //probably should put an error...
       } else {
            self.queryString += "ON " + filter(value1) + ' = ' + filter(value2);
       }
    }
    return this;
};

/*
* INSERTS
*/


/**
 * The base insert query
 * @param table
 * @returns {db.prototype.builder}
 */

builder.prototype.insert = function(table){
    //need to be worked on
    var self = this;
    self.insert = true; //to make sure we are actually inserting later on...
    self.queryString = "INSERT INTO " + filter(table);
    return this;
};


/**
 * Either updates a value or insert a value...
 * @param value
 * @returns {db.prototype.builder}
 */
builder.prototype.set = function(value){
    var self = this;
    self.values = [];
    if (!self.insert){
        if (self.updateQuery){
            //now we will just have to set the values...

            self.queryString += " SET ";            

            if (arguments.length == 2 && typeof value != 'object') {
                self.queryString += filter(value) + ' = ?';
                self.values.push(filter(arguments[1]));
            } else if (typeof value == 'object') {
                tools.each(value, function(index, value){
                    if (value){ //so we dont update a value that is empty...
                       self.queryString += filter(index) + '=?,';
                       self.values.push(filter(value));
                    }
                });
                self.queryString = self.queryString.substr(0, self.queryString.length -1);
            }
            return self;
        } else {
            return self;
        }
    } else {
        //okay now we are going to test if it's an object or just an string...
        if (typeof value == 'string' && arguments[1]){
            //well this is going to be like "set('user_name', 'blue')"
        } else if (typeof value == 'object'){
            var values = [];
            var keys = [];

            var Tstring = " ("; //temp string

            tools.each(value, function(key, i){
                if (i === 'MYSQL_DATE()'){
                    i = self.date('mysql');
                }

                Tstring += filter(key) + ',';

                values.push(i);
                keys.push(key);
            });

            if (keys.length != values.length){
                self.error = {
                    reason: 'failed'
                };
                return self;
            }

            Tstring = Tstring.slice(0, Tstring.length - 1) + ')';


            Tstring = filter(Tstring);

            Tstring += ' VALUES (';


            for (var i = 0; i < values.length; i++){
                if (i == (values.length - 1)){
                    Tstring += '?';
                } else {
                    Tstring += '?,';
                }
            }

            Tstring += ')';
           //now we just filter the whole thing again to double check :)

            Tstring = filter(Tstring);

            self.queryString += Tstring;

            self.values = values;

        }
    }
    return this;
};

builder.prototype.getID = function(){
    if (this.result && this.result.insertId){
        return this.result.insertId;
    } else {
        return 0;
    }
};

builder.prototype.alter = function(){
    //need to be worked on
};

builder.prototype.update = function(table){
    this.queryString = "UPDATE " + filter(table);
    this.updateQuery = true; //just tell the other functions its a update query...
    this.insert = false;
    return this;
};

builder.prototype.date = function(type){
    var date = new Date();
    var returnDate = '';
    if (type == 'mysql'){
        //now we need to get a usual mysql date
        var yyyy = date.getFullYear().toString();
        var mm = (date.getMonth()+1).toString(); // getMonth() is zero-based
        var dd  = date.getDate().toString();
            returnDate = yyyy + '-' + (mm[1]?mm:"0"+mm[0]) + '-' + (dd[1]?dd:"0"+dd[0]) + ' ';
            returnDate += (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + '-' + (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()) + '-' + (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds());

    }

    return returnDate;
};





/*
* Ends the builder
*/
var dbRet = new db();
module.exports = dbRet;

var sql = null;
var connected = false;

function filter(value){
    if (typeof value == 'string'){
        return value.replace(/drop[<>'"]/gi, '');
    } else {
        return value;
    }
}

function connection(){
    sql = mysql.createPool(config.adapters.mysql);
    sql.getConnection(function(err, connection){
        if (err){
            console.error(err);
            setTimeout(connection, 2000);
        } else {
            connected = true;
        }
    });

    sql.on('error', function(err){
        if (err && err.code === 'PROTOCOL_CONNECTION_LOST'){
            connected = false;
            setTimeout(connection, 2000);
        } else if (err && err.code === 'ETIMEDOUT'){
            console.log( 'timed out... retrying...')
        } else {
            console.log(err.code);
            throw err;
        }
    });
}
connection();

/*
 * Starts the other information
 */


var users = require('./user.js'),
    posts = require('./posts.js'),
    pack = require('./pack.js'),
    utilities = require('./utilites.js'),
    game = require('./game.js'),
    other = require('./other.js'),
    sessions = require('./sessions.js'),
    robot = require('./robot.js'),
    sprites = require('./sprites'),
    characterCreator = require('./charactercreator'),
    share = require('./share-group'),
    leaderboard = require('./leaderboards'),
    chat = require('./chat');


    

db.prototype.sessions = new sessions(dbRet, sequelize);
db.prototype.user = new users(dbRet, sequelize);
db.prototype.post = new posts(dbRet, sequelize);
db.prototype.packs = new pack(dbRet, sequelize);
//db.prototype.utilities = new utilities(db);
db.prototype.game = new game(dbRet, sequelize);
db.prototype.other = new other(dbRet, sequelize);
db.prototype.robot = new robot(dbRet, sequelize);
db.prototype.sprites = new sprites(dbRet, sequelize);
db.prototype.chat = new chat(dbRet, sequelize);
db.prototype.characterCreator = new characterCreator(dbRet, sequelize);
db.prototype.leaderboard = new leaderboard(dbRet, sequelize);
db.prototype.share = new share(dbRet, sequelize);








/*

wordpress = wp = {};

wordpress = wp = {
    connectionTimer: 0,
    connection: null,
    connected: false,
    query: function (query, values, callback, sort) {
        if (typeof query == 'string') {
            wordpress.connection.query(query, values, function (err, value) {
                if (err) {
                    console.error(err);
                    return false;
                }
                if (typeof sort != 'boolean' || sort == false) {
                    if (value && value.length > 0) {
                        if (typeof callback == 'function') {
                            callback(null, value);
                        }
                    } else if (value && value.length == 0) {
                        if (typeof callback == 'function') {
                            callback(null, value);
                        }
                    } else if (typeof callback == 'function') {
                        callback(null, value);
                    }
                } else if (value.length > 0 && typeof callback == 'function' && typeof sort == 'boolean' && sort == true) {
                    wp.filterResults(value, callback);
                }
            });
        }
    },
    update: function (table, query, values, callback) {
        var baseQuery = "Update " + wordpress.filter(table) + " SET ";
        baseQuery += wordpress.filter(query) + ' ';

        wordpress.query(baseQuery, values, callback);
    },
    /*
     * This will construct a simple get query
     * @param: table = "string" what table I want to select.

    get: function(table, row, query, values, limit, callback, sort) {
        tools.each(arguments, function(i, val){
            arguments[i] = wp.filter(val);
        });
        if (arguments.length < 6){
            return console.error('ERROR! mysql error');
        }

        if (sort == undefined && arguments[5] != undefined){
            sort = arguments[5]; //assigns the sort variable
        }

        if (typeof callback != 'function' && typeof arguments[4] == 'function'){
            callback = arguments[4];
        }

        var baseQuery = '';

        if (row != null) {
            baseQuery = "SELECT " + row + " FROM";
        } else {
            baseQuery = "SELECT * FROM";
        }

        baseQuery += ' ' + table + ' '; //adds the table name...
        baseQuery += 'WHERE ' + query + ' ';

        if (limit != false || limit != 0) {
            baseQuery += 'LIMIT ' + limit;
        }

        baseQuery = wordpress.filter(baseQuery); //we just filter it to remove the values that can destroy the database....
        wordpress.query(baseQuery, values, callback, sort);
    },
    connect: function () {


    }
};




wordpress.prototype = wordpress;
wordpress.connect(); //runs the connect function, which establishes the connection to the database...

module.exports = {
    //users
    getUserByUsername: function(name, callback){
        console.log(wp);
        return new wp.users.getUserByUsername(name, callback);
    },
    getUserByID: function(userID, callback){
        return new wordpress.users.getUserByID(userID, callback);
    },
    getUsersLevels: function(id, callback){
        return new wordpress.users.getUsersLevels(id, callback);
    },
    getUserByEmail: function(email, cb){
        return new wp.users.getUserByEmail(email, cb);
    },
    getUsersFriends: function(userID, callback){
        return new wordpress.users.getUsersFriends(userID, callback);
    },
    getUserMetaByID: function(userID, callback){
        return new wordpress.users.getUserMetaByID(userID, callback);
    },
    getPostByUser: function(id, callback){
        return new wordpress.users.getPostByUser(id, callback);
    },
    getGamesByUser: function(id, callback){
        return new wordpress.users.getGamesByUser(id, callback);
    },
    getUsersPerms: function(id, callback){
        return new wordpress.users.getUsersPerms(id, callback, true);
    },
    checkIfFbUserExists: function(id, callback){
        return new wordpress.users.checkIfFbUserExists(id, callback);
    },

    //posts
    insertPost: function(options, cb){
        return new wp.posts.insertPost(options, cb);
    },
    getPostByID: function(id, callback){
        return new wordpress.posts.getPostByID(id, callback);
    },
    getTaxonomies: function(post_id, taxonomy, callback){
        return new wordpress.posts.getTaxonomies(post_id, taxonomy, callback);
    },
    getThumbnail: function(id, callback){
        return new wordpress.posts.getThumbnail(id, callback);
    },
    getPostMetaByID: function(id, callback){
        return new wordpress.posts.getPostMetaByID(id, callback);
    },

    //pack
    getPackByID: function(id, callback){
        return new wordpress.pack.getPackByID(id, callback);
    },
    getPackData: function(id, callback){
        return new wordpress.pack.getPackData(id, callback);
    },
    getPacksToBeRegernated: function(callback){
        return new wordpress.pack.getPacksToBeRegernated(callback);
    },
    getPackRegenFlag: function(id, callback){
        return new wordpress.pack.getPackRegenFlag(id, callback);
    },
    getPacksByUserID: function(id, callback){
        return new wordpress.games.getPacksByUserID(id, callback);
    },

    //game
    saveGameData: function(game, callback){
      new wordpress.games.saveGameData(game, callback);
    },
    getGameData: function(id, callback){
        new wordpress.games.getGameData(id, callback);
    },
    getGameByID: function(id, callback){
        return new wordpress.games.getGameByID(id, callback);
    },
    getAnimationID: function(id, callback){
        return new wordpress.games.getAnimationID(id, callback);
    },
    getSpriteByID: function(id, callback){
        return new wordpress.games.getSpriteByID(id, callback);
    },
    getAssetByID: function(id, callback){
        return new wordpress.games.getAssetByID(id, callback);
    },

    getItemByID: function(id, callback){
        return new wordpress.games.getItemByID(id, callback);
    },
    get: function(){
      new wordpress.get(this, arguments);
    },
    filter: function(value){
        return new wordpress.utilites.filter(value);
    }

};

//loads the rest....

//separated




wordpress.users = users;
wordpress.posts = posts;
wordpress.packs = pack;
wordpress.games = game;
wordpress.utilites = utilites;
wordpress.other = other;


//we will just connect the utilites up...

wordpress.filter = wordpress.utilites.filter;
*/


Date.prototype.getMysqlTime = function() {
    var yyyy = this.getFullYear().toString();
    var mm = (this.getMonth()+1).toString(); // getMonth() is zero-based
    var dd  = this.getDate().toString();
    return (yyyy + '-' + (mm[1]?mm:"0"+mm[0]) + '-' + (dd[1]?dd:"0"+dd[0]) + ' ' + this.getHours() + '-' + this.getHours() + '-' + this.getSeconds()); // padding
};