var tools = require('../tools/');
var posts = require('./posts.js');
var extend = require('deep-extend');

var postsModel, postMeta;

var games = function(db, sequelize){
    this.db = db;
    this.posts = new posts(db);

    this.sequelize = sequelize;
    postsModel = sequelize.import(__dirname + '/models/posts');
    postMeta = sequelize.import(__dirname + '/models/posts/meta');
    return this;
};

games.prototype = {
    getGameByID: function (id, callback) {
        new this.db.builder().select('*').from(this.db.prefix('posts')).where({'post_type': 'game', 'ID': id}).execute(function(err, res){
           if (!this.isError()){
               callback(false, res);
           } else {
               callback(err, false);
           }
        });
    },
    getGamesByUser: function (id, callback) {
        var id = wordpress.filter(id);
        wordpress.get('wp_posts', null, 'post_author = ? AND post_type = "game"', [id], false, callback);
    },
    updateGamePack: function (id, data, regenFlag, callback) {
        id = wordpress.filter(id);
        if (typeof data == 'string') {
            wordpress.update('wp_postmeta', 'meta_value = ? WHERE post_id = ? AND meta_key = "data"', [data, id], callback);
        }

        if (regenFlag) {
            wordpress.update('wp_postmeta', 'meta_value = "0" WHERE post_id = ? AND meta_key = "pack_regenerate"', [id]);
        }
    },
    saveGameData: function(game, callback){
        var self = this;
        //we should also get the user for this as well...
        if (game.map){
            self.getGameByID(game.id, function(err, data){
                if (!data || data.length == 0){
                    //create a new post + the postmeta for it...
                    self.posts.insertPost({
                        'post_type': 'game',
                        'post_author': game.author,
                        'post_title': game.title,
                        'ping_status': 'open',
                        'comment_status': 'open',
                        'post_name': game.title.replace(/ /gi, '-')
                    }, function(err, id){
                        if (!err && (id || id == 0)){
                            //inserts the data into the database
                            var query = "INSERT INTO wp_postmeta (post_id, meta_key, meta_value) VALUES (?, ?, ?)";
                            new self.db.builder().query(query, [id, 'map', game.map], null, false);
                            new self.db.builder().query(query, [id, 'version', '0.15'], null, false);
                            new self.db.builder().query(query, [id, 'menu', game.menu], null, false);
                            new self.db.builder().query(query, [id, 'image', game.image], null, false);
                            new self.db.builder().update(self.db.prefix('posts')).set('guid', 'http://dev.doublehappy.co.nz/?post_type=game&#038;p=' + id).where('post_id', id).exec();
                            callback(false, id);
                        }
                    });
                } else {
                    var query = 'UPDATE wp_postmeta SET meta_value = ? WHERE post_id = ? AND meta_key = ?';
                    new self.db.builder().query(query, [game.map, game.id, 'map'], null);
                    new self.db.builder().query(query, [game.menu, game.id, 'menu'], null);
                    new self.db.builder().query(query, [game.image, game.id, 'image'], function(err, res){
                        if (res && res.affectedRows === 0){
                            //no image field huh??
                            new self.db.builder().query("INSERT INTO wp_postmeta (post_id, meta_key, meta_value) VALUES (?, ?, ?)", [game.id, 'image', game.image], null);
                        }
                    });
                    new self.db.builder().query(query, ['0.15', game.id, 'version'], null);
                    callback(false, game.id);
                }
            });
        }
    },
    updateGameStatus: function(id, status, cb){
        new this.db.builder().update(this.db.prefix('posts')).set('post_status', status).where('ID', id).exec(cb);
    },
    getGameData: function(id, callback){
        new this.db.builder().select('meta_key, meta_value').from(this.db.prefix('postmeta')).where({post_id: id}).exec(function(err, res){
            if (!err && res){
                var length = res.length;
                var map = {};
                for (var i = 0; i < length; i++){
                    if (res[i].meta_key == 'map'){
                        map.map = res[i].meta_value;
                    } else if (res[i].meta_key == 'menu'){
                        map.menu = JSON.parse(res[i].meta_value);
                    } else if (res[i].meta_key == 'image') {
                        map.image = res[i].meta_value;
                    }  else if (res[i].meta_key == 'version') {
                        map.version = res[i].meta_value;
                    }
                }
                callback(false, map);
            } else {
                callback(err, false);
            }
        });
    },
    getTerrainFile: function(id, callback){
        new this.db.builder().select('meta_value').from(this.db.prefix('postmeta')).where({'post_id': id, 'meta_key': 'frames'}).exec(function(err, res){
            if (!this.isError()){
                callback(false, res);
            } else {
                callback(err, false);
            }
        });
    },
    get: function(id, cb){
        postsModel.find({
           where: {
                ID: id
           } 
        }).success(function( data ){
            postMeta.findAll({
                where: {
                    post_id: id
                },
                attributes: ['meta_value', 'meta_key']
            }).success(function( meta ){
                cb(sortDataValues(data, meta));
            });
        });
    }
};


function sortDataValues ( data, meta ){
    var obj = data.dataValues;

    for (var i = 0; i < meta.length; i++){
        obj[ meta[i].selectedValues.meta_key ] = meta[i].selectedValues.meta_value;        
    }



    return obj;
}


module.exports = games;