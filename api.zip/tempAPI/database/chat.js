var tools = require('../tools/');
var posts = require('./posts.js');

var chat = function(db){
    this.db = db;
    this.posts = new posts(db);
    return this;
};

chat.prototype = {
    add: function(author, message, to, headers, cb){
        var self = this;
        new this.db.builder().insert(this.db.prefix('gf_chat')).set({
            author: author,
            message: message,
            receiver: to,
            headers: headers
        }).exec(function(err){
            if (err){
                console.error(err);
            }
        });
    },
    getAllForUser: function(user, cb){
        var self = this;
        if (user == 4205){
            //this user is a support staff member...
            user = 'Support';
        }
        new this.db.builder().select('*').from(this.db.prefix('gf_chat')).where({'receiver': user, 'received': 0}).exec(function(err, res){
            if (!err && res){
                cb(false, res);
                new self.db.builder().update(self.db.prefix('gf_chat')).set('received', 1).where('receiver', user).exec();
            } else {
                console.log(err);
            }
        });

    }
};


module.exports = chat;