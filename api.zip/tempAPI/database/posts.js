var tools = require('../tools/');
var bcrypt = require('bcrypt');

var posts = function(db){
    this.db = db;
    return this;
};

posts.prototype = {
    getPostByID: function (id, callback) {
        new this.db.builder().select('*').from(this.db.prefix('posts')).where('ID', id).execute(function(err, value){
           if (this.isError()){
               callback(err, false);
           } else {
               callback(false, value);
           }
        });
    },
    getPostByUser: function (id, callback) {
        var id = wordpress.filter(id);
        wordpress.get('wp_posts', null, 'post_author = ?', [id], false, callback);
    },
    insertPost: function(options, cb){
        var self = this;
        var date = new Date();

        var defaults = {
            'post_author': "",
            'post_date': date.getMysqlTime(),
            'post_date_gmt': date.getMysqlTime(),
            "post_content": "",
            "post_title": "untiltled post",
            "post_excerpt": "",
            'post_status': 'draft',
            "comment_status": "closed",
            "ping_status": "closed",
            "post_password": "",
            "post_name": "",
            "to_ping": '',
            "pinged": "",
            "post_modified": '0000-00-00 00:00:00',
            "post_modified_gmt": "0000-00-00 00:00:00",
            "post_content_filtered": "",
            "post_parent": 0,
            "guid": "",
            "menu_order": 0,
            "post_type": "post",
            "post_mime_type": "",
            "comment_count": 1
        };

        var d = tools.extend({}, defaults, options);


        var fields = '';
        var s = '';
        var values = [];
        tools.each(d, function(key, value){
            fields += ',' + key + '';
            s += ", ?";
            values.push(value);
        });

        fields = fields.slice(1);
        s = s.slice(1);

        var query = "INSERT INTO wp_posts (" + fields + ") VALUES (" + s + ")";
        new self.db.builder().query(query, values, function(err, res){
            if (err) {console.error('mysql post failed'); cb(true); return false}
            if (res && (res.insertId || res.insertId === 0)){
                cb(false, res.insertId);
            }
        }, false);
    },
    insertMeta: function(post_id, meta_key, meta_value, cb){
        new this.db.builder().insert(this.db.prefix('postmeta')).set({
            'post_id': post_id,
            'meta_key': meta_key,
            'meta_value': meta_value
        }).exec(function(err, id){
            if (this.isError()){
                if (cb){
                    cb(err, false);
                }
            } else {
                if (cb){
                    cb(false, id);
                }
            }
        });
    },
    getPostMetaByID: function (id, callback) {
        new this.db.builder().select('*').from(this.db.prefix('postmeta')).where('post_id', id).exec(function(err, res){
            if (this.isError()){
                callback(err, false);
            } else {
                callback(false, res);
            }
        });
    },
    getTaxonomies: function (id, taxonomy, cb) {
        var query = "SELECT * FROM wp_term_relationships AS tr INNER JOIN wp_term_taxonomy AS tt on tr.term_taxonomy_id = tt.term_taxonomy_id INNER JOIN wp_terms as wt ON wt.term_id = tt.term_id WHERE tt.taxonomy = ? AND tr.object_id = ?";
        //we do a ordinary query here as my simple "get" function wont be enough for a big query like this...
        new this.db.builder().query(query, [taxonomy, id], cb);
    },
    getTaxonomiesRelationShip: function(id, cb){
        new this.db.builder().select('term_taxonomy_id').from(this.db.prefix('term_relationships')).where('object_id', id).exec(function(err, res){
            if (this.isError()){
                cb(err, false);
            } else {
                cb(false, res);
            }
        });
    },
    getThumbnail: function (id, callback) {
        new this.db.builder().select('meta_key').from(this.db.prefix('postmeta')).where({'meta_key': '_thumbnail_id', 'post_id': id}).exec(function(err, value){
            if (this.isError()){
                callback(err, false);
            } else {
                callback(false, value);
            }
        });
    },
    setPostMeta: function(postID, key, value){
        var self = this;
        if (postID){
            new this.db.builder().update(this.db.prefix('postmeta')).set('meta_value', value).where({'meta_key': key, post_id: postID}).exec(function(err, res){
                if (!err && res){
                    if (res.affectedRows === 0){
                        //hmmm no postmeta with this id.... should we do something about this??? probably...
                        self.insertMeta(postID, key, value);
                    }
                }
            });
        }
    },
    setPostPass: function(id, pass, cb){
        var self = this;
        console.log(bcrypt.hashSync(pass, 8));
        new this.db.builder().update(this.db.prefix('posts')).set({
            post_password: bcrypt.hashSync(pass, 8)
        }).where('ID', id).exec(cb);
    }
};


module.exports = posts;



Date.prototype.getMysqlTime = function() {
    var yyyy = this.getFullYear().toString();
    var mm = (this.getMonth()+1).toString(); // getMonth() is zero-based
    var dd  = this.getDate().toString();
    return (yyyy + '-' + (mm[1]?mm:"0"+mm[0]) + '-' + (dd[1]?dd:"0"+dd[0]) + ' ' + this.getHours() + '-' + this.getHours() + '-' + this.getSeconds()); // padding
};