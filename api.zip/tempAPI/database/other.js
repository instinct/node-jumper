var tools = require('../tools/');
var posts = require('./posts.js');

var others = function(db){
    this.db = db;
    this.posts = new posts(db);
    return this;
};

others.prototype = {
    getAll: function(table, where, cb){
        var key = where.key;
        var value = where.value;
        var query = "SELECT * FROM wp_" + table + " WHERE ID > 84000 AND ID < 86000 AND " + key + ' = "' + value + '"';
        
        new this.db.builder().query(query, [], function(err, res){
            cb(false, res);
        });
        /*  
        new this.db.builder().select('*').from(this.db.prefix(table)).where(key, value).anexec(function(err, res){
            if (!this.isError()){
                cb(false, res);
            } else {
                cb(err, false);
            }
        });*/
    },

    getAnimationID: function (id, callback) {
        var id = wordpress.filter(id);
        wordpress.get('wp_postmeta', null, "meta_key = 'frames' AND post_id = ?", [id], false, callback);
    },
    getPacksByUserID: function (id, callback) {
        var id = wordpress.filter(id);
        wordpress.get('wp_posts', null, 'post_type="wpsc-product" and post_author = ?', [id], false, callback);
    },
    getAssetByID: function (id, callback) {
        var id = wordpress.filter(id);
        wordpress.get('wp_postmeta', null, 'post_id = ?', [id], 1, callback);
    },
    getSpriteByID: function (id, callback) {
        var id = wordpress.filter(id);
        wordpress.get('wp_gfdl_sprites', null, 'post_id = ?', [id], 1, callback);
    },
    getAnimationByID: function (id, callback) {
        new this.db.builder().select('animations').from(this.db.prefix('gfdl_items')).where('post_id', id).exec(function(err, result){
            if (!err && result){
                callback(false, result);
            } else {
                callback(err, false);
            }
        });
    },
    getImageBySpriteId: function(id, callback){
        new this.db.builder().select('filename').from(this.db.prefix('gfdl_sprites')).where('post_id', id).exec(function(err, result){
            if (!err && result){
                callback(false, result[0].filename);
            } else {
                callback(err, false);
            }
        });
    },
    insertSprite: function(id, user, title, filename, mimetype, size_w, size_h, cb) {
        new this.db.builder().insert(this.db.prefix('gfdl_sprites')).set({
            'post_id': id,
            'owner': user,
            'title': title,
            'filename': filename,
            'mimetype': mimetype,
            'size_w': size_w,
            'size_h': size_h
        }).execute(function(err){
            if (!this.isError()){
                cb(false, this.getID())
            } else {
                cb(err, false);
            }
        });


    },
    addRow: function(tableName, rowName, rowType, AI, PK){
        //var tableName, rowName, rowType, AI, PK

        var query = "ALTER TABLE " + tableName  + " ADD COLUMN " + rowName + " " + rowType + ' NOT NULL';
        if (AI){
            query += ' AUTO_INCREMENT';
        }

        if (PK){
            query += ' PRIMARY KEY';
        }

        new this.db.builder().query(query, [], function(err, value){
            if (err){console.error(err);}
        });
    },
    insertItem: function(post_id, owner, type, title, animations, sprites, robot_id, robot_var, beha, data, cb){
        new this.db.builder().insert(this.db.prefix('gfdl_items')).set({
            'post_id': post_id,
            'owner': owner || 0,
            'title': title || 'Item',
            'type': type || 'item',
            'animations': animations || '{}',
            'sprites': JSON.stringify(sprites) || '[]',
            'robot_id': robot_id || 0,
            'robot_variables': 0,
            'behaviour_type': 0,
            'behaviour_amount': 0,
            'data': data
        }).exec(function(err){
            if (!this.isError()){
                cb(false, this.getID())
            } else {
                cb(err, false);
            } 
        }); 
    },
    insertTable: function(name, rows){
        new this.db.builder().query('CREATE TABLE ' + name + ' ' + rows, [], function(err){
           if (err){
               console.error(err);
           }
        });
    }
};

module.exports = others;