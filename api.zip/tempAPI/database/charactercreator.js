var tools = require('../tools/');
var posts = require('./posts.js');

var characterCreator = function(db){
    this.db = db;
    this.posts = new posts(db);
    return this;
};

characterCreator.prototype = {
    add: function(name, file, author, price, type, cb){
        var self = this;
        new this.db.builder().insert(this.db.prefix('character_creator')).set({
            file: file,
            name: name,
            author: author,
            price: price,
            type: type
        }).exec(function(err, res){
           if (!err && res){
               var id = res.insertId;
               cb(false, id, function(path){
                  new self.db.builder().update(self.db.prefix('character_creator')).set({
                      file: path
                  }).where('id', id).exec();
               });
           }
        });
    }, getFiles: function(cb){
        new this.db.builder().select('id, file, name, price, author, type').from(this.db.prefix('character_creator')).exec(function(err, res){
           if (!err && res){
               cb(false, res);
           } else {
               cb(err, false);
           }
        });
    },
    getById: function(id, cb){
        new this.db.builder().select('id, file, name, price, author, type').from(this.db.prefix('character_creator')).where('id', id).exec(function(err, res){
            if (!err && res){
                cb(false, res);
            } else {
                cb(err, false);
            }
        });
    }
};


module.exports = characterCreator;