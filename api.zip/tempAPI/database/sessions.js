var tools = require('../tools/');

var sessions = function(db){
    this.db = db;
    return this;
};

sessions.prototype = {
	get: function(sid, cb){
		new this.db.builder().select('session').from(this.db.prefix('gf_sessions')).where('sID', sid).exec(function(err, value){
			if (!err && value){
				cb(null, value);
			} else {
				cb(err, null);
			}
		});
	}
};

module.exports = sessions;