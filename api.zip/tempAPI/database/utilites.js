var wp, wordpress;

wp = wordpress = {};

wordpress.utilites = {
    filterResults: function (result, cb) {
        if (typeof result[0].meta_value == 'string') {
            var stripedValue = result[0].meta_value.split(/[{}]/);
            stripedValue = stripedValue[1];
            if (stripedValue){
                var res = stripedValue.split(/[:;]/);
                var filterd = [];
                for (var i = 0; i < res.length; i++){
                    var va = res[i];
                    va = va.replace(/["']/gi, '');
                    if (va.length < 3 || wp.isInt(va)){
                        res.splice(i, 1);
                    } else {
                        filterd.push(va);
                    }
                }
                if (filterd.length > 0 && typeof cb == 'function'){
                    cb(filterd);
                } else if (typeof cb == 'function'){
                    cb(null);
                }
            } else {
                cb(null);
            }
        }
    },
    filter: function (data) {
        if (typeof data == 'string' && !wordpress.isInt(data)) {
            data = data.replace(/drop[<>?:"',.\/\\\(\)\*\&\^\%\$\#\@\!]/gi, '');
        }
        return data;
    },
    isInt: function (n) {
        return typeof n === 'number';
    }
};

module.exports = wordpress.utilites;