//loads the js file

var tools = require('../tools/');
var posts = require('./posts.js');

var sprites = function(db){
    this.db = db;
    this.posts = new posts(db);
    return this;
};

sprites.prototype = {
    get: function(id, cb){
        new this.db.builder().select('post_id, filename, title').from(this.db.prefix('gfdl_sprites')).where('post_id', id).exec(function(err, value){
            if (!err && value){
                cb(null, value);
            } else {
                cb(err, null);
            }
        });
    },
    newsprite: function(owner, type, title, animations, sprites, callback, character, pack){      
        var self = this;
        //we will need to add a new post as well, for stuff :)
        
        //yay... lets set out the order...
        
        var meta = [];        
        animations = JSON.parse( animations );

        for (var i in animations){
            if (animations.hasOwnProperty(i)){
                var spritesObj = animations[i].sprites;
                if (spritesObj.length){
                    for (var s = 0; s < spritesObj.length; s++){
                        meta.push({
                            id: spritesObj[s].id,
                            order: spritesObj[s].order,
                            sequence: spritesObj[s].sequenceName
                        });
                    }
                }
            }
        }

        meta = JSON.stringify(meta);
        
        self.posts.insertPost({
            'post_type': character || 'item',
            'post_author': owner,
            'post_title': title
        }, function(err, id){
            if (!err && id){
                var query = "INSERT INTO wp_gfdl_items (post_id, owner, type, title, animations, sprites, data, robot_id, robot_variables, behaviour_type, behaviour_amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
                
                new self.db.builder().insert(self.db.prefix('gfdl_items')).set({
                    post_id: id,
                    owner: owner,
                    type: type || 'item', 
                    title: title || "untitled Animation",
                    animations: JSON.stringify(animations),
                    sprites: JSON.stringify(sprites),
                    data: meta,
                    robot_id: 0,
                    robot_variables: 0,
                    behaviour_type: 0,
                    behaviour_amount: 0
                }).exec(function(err, res){
                    if (!err && res){                   
                        callback(false, id);
                    } else {
                        callback(err, false);
                    }
                });
            } else {
                console.log(err);
            }
        });
    },
    update: function(id, owner, type, title, animations, sprites, callback){
        var self = this;
        new self.db.builder().select('*').from(this.db.prefix('gfdl_items')).where('post_id', id).exec(function(err, result){
           if (!err && result && result.length == 0){
               var query = "INSERT INTO wp_gfdl_items (post_id, owner, type, title, animations, sprites, robot_id, robot_variables, behaviour_type, behaviour_amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
               new self.db.builder().query(query, [id, owner, type, title, animations, sprites, 0, 0, 0, 0], function(err, res){
                   callback(id);
               });
           } else {
               callback(id);
           }
        });
    },
    save: function(id, author, title, filename, mimetype, size_w, size_h, callback){
        var self = this;
        if (id){
            //just update with the id...
            new self.db.builder().update(this.db.prefix('gfdl_sprites')).set({
                filename: filename,
                mimetype: mimetype || 'image/png',
                size_w: size_w || 48,
                size_h: size_h || 48
            }).where('post_id', id).exec(callback);
        } else {
            self.posts.insertPost({
                'post_type': 'sprite',
                'post_author': author,
                'post_status': published  == true ? 'open' : 'closed',
                'post_title': title
            }, function(err, id){
                if (!err && id){
                    if (callback){
                        callback(id);
                    }
                }
            });
        }
    },
    getAnimations: function(id, cb){
        new this.db.builder().select('post_id, title, animations, type').from(this.db.prefix('gfdl_items')).where('post_id', id).exec(function(err, value){
            if (!err && value){
                cb(null, value);
            } else {
                cb(err, null);
            }
        });
    },
    addSprite: function(author, published, title, callback){
        //this will create the new sprite and post...
        var self = this;
        self.posts.insertPost({
            'post_type': 'sprite',
            'post_author': author,
            'post_status': published  == true ? 'open' : 'closed',
            'post_title': title
        }, function(err, id){
            if (!err && id){
                if (callback){
                    callback(id, function(filename){
                       new self.db.builder().insert(self.db.prefix('gfdl_sprites')).set({
                           post_id: id,
                           owner: author,
                           title: title,
                           filename: filename,
                           mimetype: 'image/png',
                           size_w: '48',
                           size_h: '48'
                       }).exec();
                    });
                }
            }
        });
    }
};

module.exports = sprites;