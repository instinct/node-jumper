var tools = require('../tools/');
var posts = require('./posts.js');

var robot = function(db){
    this.db = db;
    this.posts = new posts(db);
    return this;
};

robot.prototype = {
	get: function(id, cb){
		new this.db.builder().select('meta_key, meta_value').from(this.db.prefix('postmeta')).where('post_id', id).exec(function(err, value){
			if (!err && value){
				cb(null, value);
			} else {
				cb(err, null);
			}
		});
	},
	save: function(id, author, title, value, published, callback){
		var self = this;
		if (id){
			//just update with the id...
			//first we need to check that the robot can be saved
			
			new self.db.builder().select('ID').from(this.db.prefix('posts')).where({
				'post_author': author,
				'ID': id
			}).exec(function(err, res){
				if (!err && res && res.length > 0){
					new self.db.builder().update(self.db.prefix('postmeta')).set('meta_value', value).where({'post_id': id, 'meta_key': 'script'}).exec();
		            new self.db.builder().update(self.db.prefix('postmeta')).set('meta_value', '{}').where({'post_id': id, 'meta_key': 'variables'}).exec();
					new self.db.builder().select('meta_key').from(self.db.prefix('postmeta')).where({'meta_key': 'variables', 'post_id': id}).exec(function(err, res){
						if (!err && res){
		                  callback(id);
		                }
					});
				} else {
					// TODO provide reason for error
					callback(false, true);
				}
			});
		} else {
			self.posts.insertPost({
				'post_type': 'robot',
				'post_author': author,
				'post_status': published  == true ? 'open' : 'closed',
				'post_title': title
			}, function(err, id){
				if (!err && id){
					self.posts.insertMeta(id, 'script', value, null);
					self.posts.insertMeta(id,  'variables', '', null);
					if (callback){
						callback(id);
					}
				}
				else {
					// TODO provide reason for error
					callback(false,true);
				}
			});
		}		
	}
}

module.exports = robot;