var tools = require('../tools/');
var posts = require('./posts.js');

var packs = function(db){
    this.db = db;
    this.posts = new posts(db);
    return this;
};

packs.prototype = {
    getPackData: function (id, callback) {
        new this.db.builder().select('meta_value').from(this.db.prefix('postmeta')).where({'meta_key': 'data', 'post_id': id}).exec(function(err, value){
            if (this.isError()){
                callback(err, false);
            } else {
                callback(false, value)
            }
        });
    },
    createPack: function(pack, cb){
        //well just need to add a post...
        var self = this;
        if (pack.title){
            this.posts.insertPost({
                'post_author': pack.author,
                'post_content': pack.description,
                'post_title': pack.title,
                'post_status': 'draft',
                'post_type': 'wpsc-product'
            }, function(err, id){
                if (!err && id){
                    //now we add the awesome stuff...
                    //all we need to do now is add the meta stuff for the packs...
                    new self.db.builder().insert(self.db.prefix('postmeta')).set({
                       'post_id': id,
                       'meta_key': 'assets',
                       'meta_value': '[]'
                    }).exec(null);

                    new self.db.builder().insert(self.db.prefix('postmeta')).set({
                        'post_id': id,
                        'meta_key': 'data',
                        'meta_value': '[]'
                    }).exec(null);

                    new self.db.builder().insert(self.db.prefix('postmeta')).set({
                        'post_id': id,
                        'meta_key': 'pack_regenerate',
                        'meta_value': '0'
                    }).exec(null);

                    cb(false, true, id);
                } else {
                    cb(true, false);
                }
            });
        } else {
            cb(true, false);
        }

    },
    setPackRegernation: function(id){
      new this.db.builder().update(this.db.prefix('postmeta')).set('meta_value', 1).where({'meta_key': 'pack_regenerate', 'post_id': id}).exec();
    },
    getPackRegenFlag: function (id, callback) {
       new this.db.builder().select('meta_value').from(this.db.prefix('postmeta')).where({'meta_key': 'pack_regenerate', 'post_id': id}).execute(function(err, value){
          if (this.isError()){
              callback(err, false);
          } else {
              callback(false, value)
          }
       });
    },
    getAllPacks: function(callback){
       // new this.db.builder().select('meta_value')
    },
    addToPack: function(packID, assetID, cb){
        new this.db.builder().insert(this.db.prefix('ph_pack_contents')).set({
            'pack_id': packID,
            'asset_id': assetID
       }).execute(function(err, value){
          if (this.isError() && cb){
              cb(err, false);
          } else if (cb) {
              cb(false, value)
          }
       });
    },
    connectAssetToPack: function(assetID, packID, cb){
        if (assetID && packID){
          new this.db.builder().insert(this.db.prefix('ph_pack_contents')).set({
            pack_id: packID,
            asset_id: assetID
          }).exec(function(err, value){
              if (!err && value){
                console.log('connected');
              } else {
                console.log(err, value);
              }
          });
        }
    },
    getPrice: function(id, cb){
        if (id){
            new this.db.builder().select('meta_value').from(this.db.prefix('postmeta')).where({
                post_id: id,
                meta_key: '_wpsc_price'
            }).exec(cb);
        }
    },
    getGroupAllocation: function(id, cb){
        if (id){
            new this.db.builder().select('meta_value').from(this.db.prefix('postmeta')).where({
                post_id: id,
                meta_key: 'group_allocation'
            }).exec(cb);
        }
    },
    getStatus: function(id, cb){
        if (id){
            new this.db.builder().select('meta_value').from(this.db.prefix('postmeta')).where({
                post_id: id,
                meta_key: 'pack_status'
            }).exec(cb);
        }
    }
};


module.exports = packs;