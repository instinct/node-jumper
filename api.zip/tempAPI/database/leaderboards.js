var tools = require('../tools/');
var posts = require('./posts.js');


var leaderboardObj, userMeta;

var leaderboard = function(db, sequelize){
    this.db = db;
    this.posts = new posts(db);
    this.sequelize = sequelize;
    leaderboardObj = sequelize.import(__dirname + '/models/leaderboard/');
    userMeta = sequelize.import(__dirname + '/models/usermeta');
    return this;
};

leaderboard.prototype = {
   checkKey: function(key, cb){
      userMeta.find({
          where: {
            meta_key: 'api-key',
            meta_value: key
          },
          attributes: ['user_id']
      }).success(function( data ){
          if (data){
            cb(data.dataValues);
          } else {
            cb(false);
          }
      });
   },
   set: function(){},
   getScore: function(obj, cb){
      var order, where = {}, self = this;
      if (obj.order){
          switch (obj.order){
              case 'date':
                  order = 'date';
                  break;
              case 'score':
                  order = 'score';
                  break;
          }
      } 

      var filter = null
      if (obj.filter){
          //does it have a filter??, filter is really means nothing except they just want to narrow the result...
          switch (obj.filter){
              case 'user':
                filter = {
                  key: 'user',
                  value: obj.user
                }
                break;
          }        
      }

      where.game = obj.game;
      if (filter){
        where[filter.key] = filter.value;
      }

      //first we need to check the api key to see if it's legit 
      
      new this.db.builder().select('*').from(this.db.prefix('usermeta')).where({meta_key: 'api-key', meta_value: obj.apiKey}).exec(function(err, res) {
          if (!err && res){
            if (res[0]){
              new self.db.builder().select('id, user, score, game, date').from(self.db.prefix('gf_leaderboards')).where(where).order(order || 'id', 'DESC').exec(cb);
            } else {
              cb(false, false, true);
            }
          } else {
            cb(true, false);
          }          
      });     
   },
   insertScore: function(obj, cb){
      var self = this;
      new this.db.builder().select('*').from(this.db.prefix('usermeta')).where({meta_key: 'api-key', meta_value: obj.apiKey}).exec(function(err, res) {
          if (!err && res){
            if (res[0]){
                new self.db.builder().insert(self.db.prefix('gf_leaderboards')).set({
                   user: obj.user,
                   score: obj.score,
                   game: obj.game,
                   date: obj.date,
                   user_id: res[0].user_id
                }).exec(function(err, result){
                    cb(err, result);
                });              
            } else {
              cb(false, false, true);
            }
          } else {
            cb(true, false);
          }          
      });         
   },
   insertData: function(obj, cb){
      this.checkKey(obj.apiKey, function( userID ){ 
        if (obj.user && userID){        
            leaderboardObj.create({
                  user: obj.user,
                  game: obj.game,
                  data: obj.data,
                  score: obj.score,
                  user_id: userID.user_id
            }).success(function( user ){                
                cb(false, true, false);                
            });
        } else {
            cb(false, false, false);
        }
      });
   },
   updateData: function(obj, cb){
      this.checkKey(obj.apiKey, function( userID ){ 
        if (obj.user && userID){        
            leaderboardObj.find({
                where: {
                    user: obj.user,
                    game: obj.game
                }
            }).success(function( user ){        
                user.updateAttributes({
                  data: obj.data,
                  score: obj.score
                }).success(function(){
                    cb(false, true, false);
                });            
            });
        } else {
            cb(false, false, false);
        }
      });
   },
   getData: function(obj, cb){
      this.checkKey(obj.apiKey, function( userID ){  
        if (userID){  
          if (obj.user){
              leaderboardObj.find({
                  where:{ 
                    user: obj.user,
                    game: obj.game
                  },
                  attributes: ['user', 'score', 'game', 'data', 'user_id']
              }).success(function( results ){
                  if (results && results.dataValues.user_id == userID.user_id){
                    cb( false, results.dataValues , false );
                  } else if (!results) {
                      cb( false, false , false );
                  } else {
                    cb( false, false , true );
                  }
              });
            } else {
              if (!obj.offset){
                leaderboardObj.findAll({
                    where:{ 
                      game: obj.game
                    },       
                    order: obj.order + ' DESC',           
                    attributes: ['user', 'score', 'game', 'data']
                }).success(function( results ){
                    if (results) {
                      cb( false, sortResults(results) , false );
                    } else {
                      cb( false, false , true );
                    }
                });
              } else {
                leaderboardObj.findAll({
                    where:{ 
                      game: obj.game
                    }, 
                    order: obj.order + ' DESC',      
                    offset: obj.offset,
                    limit: obj.limit,          
                    attributes: ['user', 'score', 'game', 'data']
                }).success(function( results ){
                    if (results) {
                      cb( false, sortResults(results) , false );
                    } else {
                      cb( false, false , true );
                    }
                });
              }
            }      
        } else {
          cb(false, false, true);
        }
      });
    }
};


function sortResults( results ){
  var data = [];
  for (var i = 0; i < results.length; i++){
     data.push(results[i].dataValues);
  }
  return data;
}

module.exports = leaderboard;