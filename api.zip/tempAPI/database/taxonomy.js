/* The big joins class... */


