/**
* Main Share group function, this will handle all the database connections...
*/

var tools = require('../tools/');
var posts = require('./posts.js');

var share = function(db){
    this.db = db;
    this.posts = new posts(db);
    return this;
};

share.prototype = {
    updateGroup: function(author, users, status, gameID){
        new this.db.builder().update(this.db.prefix('gf_share_groups')).set({
            owner: author,
            users: users,
            status: status || 'Open'
        }).where('gameID', gameID).exec(function(err){
            if (err){
                console.error(err);
            }
        });
    },
    createGroup: function(author, users, status, gameID){
        new this.db.builder().insert(this.db.prefix('gf_share_groups')).set({
            owner: author,
            users: users,
            status: status || 'Private',
            gameID: gameID || 0
        }).exec(function(err){
            if (err){
                console.error(err);
            }
        });
    },
    getGroup: function(id, cb){
        new this.db.builder().select('id, owner, users, status').from(this.db.prefix('gf_share_groups')).where('gameID', id).exec(function(err, value){
            if (!err && value){
                cb(false, value);
            } else {
                cb(err, false);
            }
        });
    },
    getTeachingGroup: function(id, cb){
        new this.db.builder().select('id, owner, users, status').from(this.db.prefix('gf_share_groups')).where('teacherID', id).exec(function(err, value){
            if (!err && value){
                cb(false, value);
            } else {
                cb(err, false);
            }
        });
    },
    createTeacherGroup: function(author, users, status, teacherID, callback){
        var self = this;
        new this.db.builder().insert(this.db.prefix('gf_share_groups')).set({
            owner: author,
            users: users,
            status: status || 'Private',
            gameID: 0,
            teacherID: teacherID
        }).exec(function(err, value){
            if (err){
                console.error(err);
            } else {
                //all the yukky buddy press crap...
                new self.db.builder().insert(self.db.prefix('bp_groups')).set({
                    creator_id: author,
                    name: 'gamefroot class 101',
                    slug: 'gamefroot-class',
                    description: 'My Class group',
                    status: 'hidden',
                    is_invitation_only: 1,
                    enable_wire: 1,
                    enable_forum: 0,
                    enable_photos: 1,
                    photos_admin_only: 0,
                    date_created: new Date()
                }).exec(function(err, value){
                    if (!err && id){
                        var id = value.insertedId;
                        new self.db.builder().insert(self.db.prefix('bp_groups')).set({
                            group_id: id,
                            meta_key: 'total_member_count',
                            meta_value: 1
                        }).exec();
                        new self.db.builder().insert(self.db.prefix('bp_groups')).set({
                            group_id: id,
                            meta_key: 'last_activity',
                            meta_value: 1
                        }).exec();
                        new self.db.builder().insert(self.db.prefix('bp_groups')).set({
                            group_id: id,
                            meta_key: 'invite_status',
                            meta_value: 'admins'
                        }).exec();

                        new self.db.builder().insert(self.db.prefix('bp_groups_members')).set({
                            group_id: id,
                            user_id: author,
                            inviter_id: 0,
                            is_admin: 1,
                            is_mod: 0,
                            user_title: 'Group Admin',
                            date_modified: new Date(),
                            comments: "",
                            is_confirmed: 1,
                            is_banned: 0,
                            invite_sent: 0
                        }).exec();



                    }
                });
                callback(false, value.insertedId);
            }
        });
    },
    updateTeacherGroup: function(author, users, status, teacherID){
        new this.db.builder().update(this.db.prefix('gf_share_groups')).set({
            owner: author,
            users: users,
            status: status || 'Open'
        }).where('teacherID', teacherID).exec(function(err){
            if (err){
                console.error(err);
            }
        });
    },
    getUsersGroups: function (id, cb){
        new this.db.builder().select('id, name').from(this.db.prefix('gf_share_groups')).where('owner', id).exec(function(err, data){
           if (!err && data){
               cb(false, data);
           } else {
               console.log(err);
           }
        });
    }
};


module.exports = share;