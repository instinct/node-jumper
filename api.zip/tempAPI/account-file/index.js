var crypto = require('crypto'),
    wp = require('../database/'),
    bcrypt = require('bcrypt'),
    tools = require('../tools/'),
    emailReg = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
var request = require('request');

/**
 * Does pretty much everything with login, building accounts and registration...
 * @param username
 * @param password
 * @param req
 * @param res
 * @constructor
 */
var Account = function(username, password, req, res){
    this.usrn = username;
    this.psw = password;
    this.md5 = crypto.createHash('md5');
    this.req = req;
    this.res = res;
    return this;
};

/**
* This function is the core login code, it will just login.
*/

Account.prototype.login = function(){
  var self = this;
  if (this.usrn && emailReg.test(this.usrn)){
  	wp.user.getUserByEmail(this.usrn, function(err, result){
        self.checkPassword(err, result);
    });
  } else {
    wp.user.getUserByUsername(this.usrn, function(err, result){
        self.checkPassword(err, result);
    });  
  }        
};

/**
*   This function will send the response
*   @param err {object || false} The error object (returned for the database object)
*   @param user {object || false} User object
*/

Account.prototype.checkPassword = function(err, user){
  var self = this;
  if (!err && user){
      var sent = false;
      tools.each(user, function(i, user){
        if (user && (user.version || user.version == 0)){   
          if (user.version == 1){
              //my new way of login :)
              var psw = user.user_pass;
              if (bcrypt.compareSync(self.psw, psw)){
                  sent = true;
                  self.loginSuccess(user.ID);
              }
          } else {
            sent = true;
            request.post({
              headers: {'content-type' : 'application/x-www-form-urlencoded'},
              url: 'http://gamefroot.com/wp/wp-admin/admin-ajax.php',
              body: 'log=' + user.user_login + '&pwd=' + self.psw + '&action=ajaxlogin&remember=' + false
            }, function(err, response, body){
                body = JSON.parse(body);
                if (!err && body && !body.loggedin){
                  self.res.json({
                      result: 'fail',
                      reasonID: 1,
                      reason: 'username or password'
                  });
                } else {
                  self.loginSuccess(user.ID);
                }
            });
          }
        }
      });
      
      //we delay the default for 1 second because, nodejs is just too quick....
      setTimeout(function(){
        if (sent == false){
          self.res.json({
              result: 'fail',
              reasonID: 1,
              reason: 'username or password'
          });
        } 
      }, 1000);
  } else {
    self.res.json({
        result: 'fail',
        reasonID: 2,
        reason: 'username or password'
    });
  }
};

/**
*   This function will send the response
*   userID {number} The userID
*/

Account.prototype.loginSuccess = function(userID){
    this.createStardardUserJSON(userID);
};


/**
 * This function will create a standard users...
 * @param userID
 */
Account.prototype.createStardardUserJSON = function(userID){
    var self = this;
    wp.user.getUserByID(userID, function(err, user){
          //we also need to get the users subscriptions as well for pro....
          
          if (!err && user){
              if (user.fb_image){
                  user.isFB = true;
                  user.picture = user.fb_image;
              } else {
                try {
                  if (user.user_email && user.user_email.length > 3){
                      user.picture = 'http://www.gravatar.com/avatar/' + self.md5.update(user.user_email).digest('hex') + '?d=identicon&r=g&s=42';
                  }
                } catch (e){
                  console.error( e, '121 - account/index.js' );
                }
              }

              if (user.fb_uid){
                user.isFB = true;
              }
          }         
  
          user.permissions = user.capabilites;
          user.page = 'dev.gamefroot.com/author/' + user.user_nicename;

          self.res.json({
              id: user.ID,
              name: user.user_login,
              page: user.page,
              email: user.user_email,
              picture: user.picture,
              permissions: user.permissions || [],
              groups: user.groups,
              level: user.level,
              isFB: user.isFB || false,
              result: "Success"
          });          
    });
};

/**
* Check Password
*/

Account.prototype.checkPass = function(){
    var self = this;
    wp.user.getUserByID(this.usrn, function(err, user){
        if (user){
            user = user[0];
            if (user){
                if (user.version == 1){
                    //my new way of login :)
                    var psw = user.user_pass;

                    if (bcrypt.compareSync(self.psw, psw)){
                        self.res.json({
                            result: true,
                            message: 'Password was successful'
                        });
                    } else {
                        self.res.json({
                            result: false,
                            message: 'Password was Wrong'
                        });
                    }
                } else {
                    //cb(true, false);
                }
            }
        }
    });
};

/**
* Create an account...
* @param: re-password : {string} the confirm password
* @param: email : {string} the email of the user....
*/

Account.prototype.createACC = function(email, repass, ref){
    var self = this;
    if (self.psw == repass){
        //now we need to check if the email exists...
        wp.user.getUserByEmail(email, function(err, res){
           if (!err && (res && res.length == 0)){
               //no one has that email yay :)
               //so now we hash his password...
               var hashPass = bcrypt.hashSync(self.psw, 10);
               delete self.psw; //so no one can use the variable after we have used it...
               if (hashPass){
                   //now that we have the correct information we will insert the user in the database...
                   //we need to get the date :(
                   wp.user.insertUser(self.usrn, hashPass, self.usrn, email, '', "MYSQL_DATE()", '', 0, self.usrn, 1, ref, function(err, id){
                       if (!err && id){
                          self.res.json({
                             result: 'success'
                          });
                           console.log('done??');
                       } else {
                           console.log(err);
                       }
                   });
               } else {
                   console.log('failed hash');
               }
           } else {
              //console.log( err, res );
              //someone already uses that email address...
              self.res.json({
                 result: 'failed',
                 reason: 'email'
              });
           }
        });
    } else {
        self.res.json({
            result: false,
            reason: 'confirm',
            message: 'Confirm password and password didn\'t match'
        });
    }
};

Account.prototype.createFBACC = function(options){
    var self = this;
    console.log('creating user!');
    if ( typeof options == 'string') {
      try {
        options = JSON.parse( options );
      } catch (e){
        console.log(e , options );
        return false;      
      }
    }

    var temp = {
        usermeta: {
            fb_uid: options.id,
            first_name: options.first_name,
            last_name: options.last_name,
            nickname: options.username || (options.first_name + '_' + options.last_name).replace(/ /gi, ''),
            user_pass: Math.random(),
            user_pack: '{}',
            wp_capabilites: 'a:1:{s:10:"subscriber";b:1;}',
            wp_user_level: '0',
            fb_image: options.profileImage
        },
        user: {
            user_login: options.username || options.username || (options.first_name + '_' + options.last_name).replace(/ /gi, ''),
            user_pass: options.id,
            user_registered: new Date(),
            display_name: options.name,
            user_nicename: options.name,
            user_email: options.email || '',
            version: 1
        }
    };

    wp.user.insertFBUser(temp, function(err, res){
       if (!err && res){
           if (res){
               self.createStardardUserJSON(res);
           }
       } else {

           console.log( err, res );
       }

    });
};

/**
* FB Connection
* @returns {Account}
*/

Account.prototype.fbLogin = function(fullres){
    var self = this;
    wp.user.getUserByFBID(this.usrn, function(err, res){
       if (!err && res && res.user_id){
           var userID = res.user_id;
           if (userID){
                self.createStardardUserJSON(userID);
           }
       } else {
           self.createFBACC(fullres);
           //awww... no user with that fb id.... hmm??? what should we do then???
       }
    });
    return this;
};


/**
 * Exports the module...
 * @type {Account}
 */
module.exports = Account;