/**
 * Global adapter config
 * 
 * The `adapters` configuration object lets you create different global "saved settings"
 * that you can mix and match in your models.  The `default` option indicates which 
 * "saved setting" should be used if a model doesn't have an adapter specified.
 *
 * Keep in mind that options you define directly in your model definitions
 * will override these settings.
 *
 */


var hostname = require('os').hostname();

module.exports.adapters = {
	"default": "mysql",
	// MySQL is the world's most popular relational database.
  	// Learn more: http://en.wikipedia.org/wiki/MySQL
	mysql: {
		host: "localhost",
		user: hostname == 'server.gamefroot.com' ? 'gamefroo' : 'gfstag_gamefroot',
		password: hostname == 'server.gamefroot.com' ? 'SPEMU2w~VwECF1ZU=*' : 'E4cmt@ollb0',
		database: hostname == 'server.gamefroot.com'? "gamefroo_db1" : "gfstag_gamefroot"
	},
	//the port the mysql server is on
	port: 3306,
	//log all the information 
	logging: false
}
