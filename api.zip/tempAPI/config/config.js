/* main config file for gamefroots node.js stuff */



//https://github.com/dominictarr/rc
//https://github.com/cgmartin/sailsjs-angularjs-bootstrap-example/tree/master/config
//http://sequelizejs.com/docs/latest/usage#basics


var hostname = require('os').hostname();

var DBConfig;

if (hostname == 'server.gamefroot.com'){
	DBConfig = {
		host: 'localhost',
		user: 'gamefroo',		
		password: 'SPEMU2w~VwECF1ZU=*',
		database: 'gamefroot_db1',
		supportBigNumbers: true
	}
} else if (hostname == 'server.kiwijs.org'){
	DBConfig = {
		host: 'localhost',
		user: 'gfstag_gamefroot',		
		password: 'E4cmt@ollb0',
		database: 'gfstag_gamefroot',
		supportBigNumbers: true,
		daStashRedirect: 'staging.gamefroot.com:8081'
	}
} else {
	DBConfig = {
		host: 'localhost',
		user: 'root',		
		password: '',
		database: 'dev_gamfroot',
		supportBigNumbers: true		
	}
}



var config = {
	basedir: __dirname,
	host: hostname,
	db: DBConfig,
	acceptedUploads: ['png', 'gif', 'jpg', 'zip'],
	acceptedUploadTypes: ['terrain', 'tile', 'character', 'character-platformer', 'item']
};

if (hostname == 'server.gamefroot.com'){
	config.location = 'gamefroot.com';
} else if (hostname == 'server.kiwijs.org'){
	config.location = 'http://staging.gamefroot.com:8081';
	config.name = 'staging';
	config.daStashRedirect = 'dev.gamefroot.com';
} else {
	config.location = 'http://dev.gamefroot.com';
	config.name = 'dev';
	config.daStashRedirect = 'dev.gamefroot.com';
}


global.config = config;


