/**
 * Winston Logging 
 * https://github.com/flatiron/winston
 *
 *
 *
 *
 *
 *
 */



module.exports.logging = {
	location: 'logs/'
}