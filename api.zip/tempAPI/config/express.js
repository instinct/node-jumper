var hostname = require('os').hostname();
module.exports = {
	port: hostname == 'server.kiwijs.org' ? 8081 : 80,
	host: hostname,
	path: hostname == 'server.kiwijs.org' ? 'http://staging.gamefroot.com:8081' : 'http://dev.gamefroot.com'
}