var db = require('../database/');
var express = require('express');
var app = module.exports = express();


/**
* Leader boards
*/


app.post('/api/leaderboards/data/set', function(req, res){   
    res.header('Access-Control-Allow-Origin', '*'); 
    var obj = {
        date: new Date(),
        score: req.param('score'),
        user: req.param('user'),
        game: req.param('game'),
        apiKey: req.param('api-key'),
        data: req.param('data'),
        result: "Success"
    };

    if (obj.user){
        obj.user = obj.user.replace(/"/gi, '');
    }

    if (!obj.apiKey){
        res.status(401).json({
            error: true,
            msg: 'Your request didn\'t have an api key, so it was rejected'
        });
        return false;
    } 

    db.leaderboard.insertData(obj, function(err, data, apiKeyRejection){
        console.log(err, data, apiKeyRejection);
       if (!err && data){
            res.json(obj);
       } else {
            if (apiKeyRejection){
                res.status(401).json({
                     error: true,
                    msg: 'Your request didn\'t have a valid api key, so it was rejected'
                });
            } else {
                res.json({err: true, result: "failed"});
                console.log( err );
            }
       }
    });
});


app.post('/api/leaderboards/data/update', function(req, res){   
    res.header('Access-Control-Allow-Origin', '*'); 
    var obj = {
        date: new Date(),
        score: req.param('score'),
        user: req.param('user'),
        game: req.param('game'),
        apiKey: req.param('api-key'),
        data: req.param('data'),
        result: "Success"
    };

    if (obj.user){
        obj.user = obj.user.replace(/"/gi, '');
    }

    if (!obj.apiKey){
        res.status(401).json({
            error: true,
            msg: 'Your request didn\'t have an api key, so it was rejected'
        });
        return false;
    } 

    db.leaderboard.updateData(obj, function(err, data, apiKeyRejection){
       if (!err && data){
            res.json(obj);
       } else {
            if (apiKeyRejection){
                res.status(401).json({
                     error: true,
                    msg: 'Your request didn\'t have a valid api key, so it was rejected'
                });
            } else {
                res.json({err: true, result: "failed"});
                console.log( err );
            }
       }
    });
});



app.get('/api/leaderboards/data/get', function(req, res){
    res.header('Access-Control-Allow-Origin', '*');
    var obj = {
        date: new Date(),
        score: req.param('score'),
        user: req.param('user'),
        game: req.param('game'),
        apiKey: req.param('api-key'),
        limit: req.param('limit') || false,
        offset: req.param('offset') || false,
        order: req.param('order') || 'id',
        result: "Success"
    };

    if (obj.user){
        obj.user = obj.user.replace(/"/gi, '');
    }

    if (!obj.apiKey){
        res.status(401).json({
            error: true,
            msg: 'Your request didn\'t have an api key, so it was rejected'
        });
        return false;
    } 

    db.leaderboard.getData(obj, function(err, data, apiKeyRejection){
       if (!err && data){
            res.json(data);
       } else {
            if (apiKeyRejection){
                res.status(401).json({
                    error: true,
                    msg: 'Your request didn\'t have a valid api key, so it was rejected'
                });
            } else {
                res.json({err: true, result: "Your game doesn't exists!"});
            }
       }
    });
});



app.post('/api/leaderboards/set', function(req, res){
    res.header('Access-Control-Allow-Origin', '*');
    var obj = {
        date: new Date(),
        score: req.param('score'),
        user: req.param('user'),
        game: req.param('game'),
        apiKey: req.param('api-key'),
        result: "Success"
    };

    if (obj.user){
        obj.user = obj.user.replace(/"/gi, '');
    }

    if (!obj.apiKey){
        res.status(401).json({
            error: true,
            msg: 'Your request didn\'t have an api key, so it was rejected'
        });
        return false;
    } 

    db.leaderboard.insertScore(obj, function(err, data, apiKeyRejection){
       if (!err && data.affectedRows){
            res.json(obj);
       } else {
            if (apiKeyRejection){
                res.status(401).json({
                     error: true,
                    msg: 'Your request didn\'t have a valid api key, so it was rejected'
                });
            } else {
                res.json({err: true, result: "failed"});
                console.log( err );
            }
       }
    });
});

app.get('/api/leaderboards/get', function(req, res){
    res.header('Access-Control-Allow-Origin', '*');
    var obj = {
        order: req.param('order'),
        game: req.param('game'),
        user: req.param('user'),
        apiKey: req.param('api-key'),
        filter: req.param('filter')
    };

    if (!obj.apiKey){
        res.status(401).json({
            error: true,
            msg: 'Your request didn\'t have an api key, so it was rejected'
        });
        return false;
    } 

    db.leaderboard.getScore(obj, function(err, data, apiKeyRejection){  

       if (!err && data){
            res.json(data);            
       } else {
            if (apiKeyRejection){
                res.status(401).json({
                     error: true,
                    msg: 'Your request didn\'t have a valid api key, so it was rejected'
                });
            } else {
                res.json({err: true, result: "failed"});
            }           
       }
    });
});


module.exports = app;


