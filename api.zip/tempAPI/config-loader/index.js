/**
 * A nice an simple configuration loader
 *
 * It will load all the modules in a directory and merge them with a configure var then merge them with any defaults and then returned 
 */


var fs = require('fs');
var extend = require('deep-extend');

module.exports = function( src, defaults){
	var config = {};
	

	var files = fs.readdirSync( src );
	for (var i = 0; i < files.length; i++){
		var _temp = require(src + files[i]);
		for (var key in _temp){
			config[key] = _temp[key];
		}
	}

	return extend(defaults, config);
};