var cluster = require('cluster');
var cpus = require('os').cpus();

var length = 1;

/**
 * Set up for the cluster
 */

cluster.setupMaster({
    exec: './index'
});


for (var i = 0; i < length; i++){
    cluster.fork();
}

cluster.on('exit', function(){
    //your not allowed to die on me now!, revive!!! zap!!! hes alive!!
    cluster.fork();
});


console.log('Server starting up!, port 80...');