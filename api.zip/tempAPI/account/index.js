var db = require('../database/');
var hat = require('hat');
var express = require('express');
var app = express();

var Account = require('../account-file/');

/**
* ACCOUNT API
*/

app.get('/api/account/get/:userid', function(req, res){
    var userid = req.param('userid');
    //gets a user id with the specific id.
    res.status(404).json({empty: true});
});


app.get('/api/account/me', function(req, res){
    res.header('Access-Control-Allow-Origin', '*');
    if (req && req.session && req.session.user){
        res.json(req.session.user);
    } else if (res) {
        res.json({
            response: "failed",
            reason: "not loggedin"
        });
    }
});

app.post('/api/account/login', function(req, res){
   res.header('Access-Control-Allow-Origin', '*');
   var type = req.param('type');
   if (type == 'fb'){
       new Account(req.param('id'), 'fb', req, res).fbLogin(req.param('fullRes'));
   } else {
       var account = new Account(req.param('usrn'), req.param('psw'), req, res);
       if (req.param('register')){
           account.createACC(req.param('email'), req.param('repsw'));
       } else { 
           account.login();
       }
   }
});

app.all('/api/account/register', function(req, res){
    res.header('Access-Control-Allow-Origin', '*');
    var refre = req.param('ref') || false;
    var account = new Account(req.param('usrn'), req.param('psw'), req, res);
        account.createACC(req.param('email'), req.param('repsw'), refre);
});



app.post('/api/account/check', function(req, res){
    var account = new Account(req.session.user.id, req.param('psw'), req, res);
    account.checkPass();
});


app.all('/api/account/logout', function(req, res){
    res.header('Access-Control-Allow-Origin', '*');
    res.json({
        response: true,
        message: "DONE"
    });
});

app.get('/api/account/dev', function(req, res){
    //this will generate a api-key for you... and attach it to your account...
    var apiKey = hat();
    if ( req.session && req.session.user && req.session.user.id ){
        db.user.attachApiKey(req.session.user.id, apiKey, function(err, result){
            if (!err && result){
                res.status(200).json({result: true, apiKey: apiKey});
            } else {
                res.status(200).json(err);
            }
        });
        
    } else {
        res.status(401).json({
            error: true,
            msg: "Sorry, you\'r not allowed to be here, please login and try again!"
        });
    }
});

module.exports = app;

