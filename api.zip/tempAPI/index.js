var express = require('express');
var app = express();


var bodyParser = require('body-parser');

var leaderboard = require('./leaderboard/index.js');
var account = require('./account/index.js');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
        
app.use(leaderboard);
app.use(account);



app.all('/api/*', function(req, res){
    res.status(404).json({msg: 'Can\'t find', path: req.path});
});

app.listen(8081, '198.206.133.200');